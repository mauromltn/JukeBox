-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Apr 27, 2025 alle 02:38
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MONTANEMAURO`
--
CREATE DATABASE IF NOT EXISTS `MONTANEMAURO` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `MONTANEMAURO`;

-- --------------------------------------------------------

--
-- Struttura della tabella `cantanti`
--

CREATE TABLE `cantanti` (
  `id` int(11) NOT NULL,
  `nome_cognome` varchar(100) NOT NULL,
  `nome_arte` varchar(100) NOT NULL,
  `nazionalita` varchar(50) NOT NULL,
  `anno_nascita` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `cantanti`
--

INSERT INTO `cantanti` (`id`, `nome_cognome`, `nome_arte`, `nazionalita`, `anno_nascita`) VALUES
(1, 'Aubrey Drake Graham', 'Drake', 'Canada', 1986),
(2, 'Kendrick Lamar Duckworth', 'Kendrick Lamar', 'USA', 1987),
(3, 'Jacques Webster II', 'Travis Scott', 'USA', 1991),
(4, 'Amala Ratna Zandile Dlamini', 'Doja Cat', 'USA', 1995),
(5, 'Solána Imani Rowe', 'SZA', 'USA', 1990),
(6, 'Elizabeth Woolridge Grant', 'Lana Del Rey', 'Stati Uniti', 1985);

-- --------------------------------------------------------

--
-- Struttura della tabella `canzoni`
--

CREATE TABLE `canzoni` (
  `id` int(11) NOT NULL,
  `titolo` varchar(100) NOT NULL,
  `nome_cantante` varchar(100) NOT NULL,
  `durata` time NOT NULL,
  `genere` varchar(50) NOT NULL,
  `anno_uscita` int(11) NOT NULL,
  `id_cantante` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `canzoni`
--

INSERT INTO `canzoni` (`id`, `titolo`, `nome_cantante`, `durata`, `genere`, `anno_uscita`, `id_cantante`) VALUES
(1, 'SICKO MODE', 'Travis Scott', '00:05:12', 'Hip-Hop', 2018, 3),
(2, 'HUMBLE.', 'Kendrick Lamar', '00:02:57', 'Rap', 2017, 2),
(3, 'Passionfruit', 'Drake', '00:04:58', 'R&B', 2017, 1),
(4, 'Kill Bill', 'SZA', '00:02:33', 'Soul', 2022, 5),
(5, 'Woman', 'Doja Cat', '00:03:03', 'Pop', 2021, 4),
(9, 'West Coast', 'Lana Del Rey', '00:04:26', 'Pop', 2014, 6);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `cantanti`
--
ALTER TABLE `cantanti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `canzoni`
--
ALTER TABLE `canzoni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_cantante` (`id_cantante`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `cantanti`
--
ALTER TABLE `cantanti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `canzoni`
--
ALTER TABLE `canzoni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `canzoni`
--
ALTER TABLE `canzoni`
  ADD CONSTRAINT `canzoni_ibfk_1` FOREIGN KEY (`id_cantante`) REFERENCES `cantanti` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
